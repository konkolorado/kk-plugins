from kk.plugin1.main import app, name

all = ["app", "name"]

__version__ = '0.1.0'
