from kk.core.core import app, name

all = ["app", "name"]

__version__ = '0.1.0'
